export function anti_32k_bypass(){
    let anti_32k = 
    [
        "WiredWolf44537",
        "dragonum1988"
    ]
    return anti_32k
}

export function ingamebanbypass(){
    let ingameban = 
    [
        "test",
        "test"
    ]
    return ingameban
}

export function invseebypass(){
    let invsee = 
    [
        "dragonum1988"
    ]
    return invsee
}
export function tpbypass(){
    let tp = 
    [
        "dragonum1988"
    ]
    return tp
}

export function antikickbypass(){
    let kick = 
    [
        "dragonum1988"
    ]
    return kick
}

export function banned_words_bypass(){
    let banned_words_bypas = 
    [
        "dragonum1988",
        "WiredWolf445347"
    ]
    return banned_words_bypas
}