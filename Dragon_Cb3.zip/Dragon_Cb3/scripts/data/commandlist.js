export function helplist_team(){
    const help = [
        "!tc <message>",
        "!teamchat <message>",
        "!tp <player>",
        "!kick <player>",
        "!invsee <player>",
        "!ban",
        "!unban",
        "/scriptevent bansystem:bancmd <ban_message>",
        "/scriptevent plotsystem:plotname"
    ]
    return help
}

export function helplist(){
    const help = [
        "derzeit noch nicht verfügbar"
    ]
    return help
}