export function banword(){
    let banword_list = 
    [
        "hier das gebante word",
        "test"
    ]
    return banword_list
}