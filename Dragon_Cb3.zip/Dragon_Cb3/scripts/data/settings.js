import { set_chat_connection } from "../main";

export const settings =  {
    chat_connection() {
        
        let chatconnction = true
        return chatconnction

    }
}