export function bannendlist(){
    let banlist = 
    [
        "pl:JustinMD2000;bg:hausverbot",
        "pl:name;bg:bangrund"


    ]
    return banlist
}