export function enchantmentlist(){
    let enchantmentlist1 = [
        "mending",
        "unbreaking" ,
        "vanishing",
        "aqua_affinity",
        "blast_protection",
        "binding",
        "depth_strider",
        "feather_falling",
        "fire_protection",
        "frost_walker",
        "projectile_protection",
        "protection",
        "respiration",
        "soul_speed",
        "thorns",
        "bane_of_arthropods",
        "efficiency",
        "fire_aspect",
        "looting",
        "impaling",
        "knockback",
        "sharpness",
        "smite",
        "channeling"
    ]
    return enchantmentlist1
}
export function enchantmentlistlevel(){
    let enchantmentlistlevel1 = [
        "en:mending,lvl:1",
        "en:unbreaking,lvl:3",
        "en:vanishing,lvl:1",
        "en:aqua_affinity,lvl:1",
        "en:blast_protection,lvl:4",
        "en:binding,lvl:1",
        "en:depth_strider,lvl:3",
        "en:feather_falling,lvl:4",
        "en:fire_protection,lvl:4",
        "en:frost_walker,lvl:2",
        "en:projectile_protection,lvl:4",
        "en:protection,lvl:4",
        "en:respiration,lvl:3",
        "en:soul_speed,lvl:3",
        "en:thorns,lvl:3",
        "en:bane_of_arthropods,lvl:5",
        "en:efficiency,lvl:5",
        "en:fire_aspect,lvl:2",
        "en:looting,lvl:3",
        "en:impaling,lvl:5",
        "en:knockback,lvl:3",
        "en:sharpness,lvl:5",
        "en:smite,lvl:5",
        "en:channeling,lvl:1",
    ]
    return enchantmentlistlevel1
    
}